<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network (OSSN)
 * @author    OSSN Core Team <info@openteknik.com>
 * @copyright (C) OpenTeknik LLC
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
?>
<!-- Add your custom logo -->
<div style="text-align: center; margin-bottom: 20px;">
    <img src="<?php echo ossn_theme_url('images/logo.jpg'); ?>" alt="Site Logo" style="max-width: 200px; height: auto;" />
</div>

<div style="text-align: center; margin-bottom: 20px;">
    <h2>Welcome to Modern Social Club</h2>
    <p>Modern Social Club is by invite only.</p>
    <p>Please refer to our application page to join:</p>
    <a href="https://www.modernsocialclub.org/member" target="_blank" class="btn btn-primary">Apply for Membership</a>
</div>

<div style="text-align: center; margin-top: 20px;">
    <p>Already a member? Use the login button above to access your account.</p>
</div>
