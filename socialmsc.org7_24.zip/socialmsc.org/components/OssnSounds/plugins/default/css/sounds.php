.ossn-chat-windows-long .ossn-chat-pling {
	line-height:2;
	padding-left: 4px;
}
.ossn-chat-pling {
	display: inline;
}
.ossn-message-pling {
	display: inline;
	padding-left: 10px;
}