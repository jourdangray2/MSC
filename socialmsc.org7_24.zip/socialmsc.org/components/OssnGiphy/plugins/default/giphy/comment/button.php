<div class="ossn-comment-attach-photo giphy-comment-icon-container">
	<div class="position-absolute giphy-container">
		<div class="giphy-container-inner">
        	<span class="search-giphy" placeholder="Search Giphy" contenteditable="true"></span>
            <a class="close-giphy-container"><i class="fa fa-times"></i></a>
            <span class="giphy-powerd-text"><?php echo ossn_print('ossngiphy:powered');?></span>
        	<div class="giphy-list"></div>
        </div>
	</div>
	<i class="giphy-icon"></i>
</div>